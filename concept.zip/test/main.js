
class Player {

    constructor(x, y, width, height, context, image, canvas) {
        this.type = 'player';
        this.x = x;
        this.y = y;
        this.speedX = 1.5;
        this.speedY = 0; // 1.5
        this.width = width;
        this.height = height;
        this.context = context;
        this.image = image;
        this.canvas = canvas;
    }

    show() {
        this.context.drawImage(this.image, this.x, this.y, this.width, this.height);
    }

    clear() {
        this.context.clearRect(this.x, this.y, this.width, this.height);
    }

    move() {
        this.x += this.speedX;
        this.y += this.speedY;

        if (this.x >= ((this.canvas.width / 2) - this.width))
        {
            this.x = (this.canvas.width / 2) - this.width;
        }

        // up and down
        if (this.y <= 0)
        {
            this.y = 0;
        }
        else if (this.y >= (this.canvas.height - this.height)) {
            this.y = this.canvas.height - this.height;
        }
    }
}

class Obstacle {

    constructor(x, y, width, height, context, image, canvas) {
        this.type = 'obstacle';
        this.x = x;
        this.y = y;
        this.speedX = 1.5; // 1.5
        this.speedY = 0; // 1.5
        this.width = width;
        this.height = height;
        this.context = context;
        this.image = image;
        this.canvas = canvas;
    }

    show() {
        this.context.drawImage(this.image, this.x, this.y, this.width, this.height);
    }

    clear() {
        this.context.clearRect(this.x, this.y, this.width, this.height);
    }

    move() {

        this.x -= this.speedX;
    }
}
////////////////////////////////////

// MAIN WINDOW
const WINDOW = {
    canvas: document.querySelector("#canvas"),
    context: document.querySelector("#canvas").getContext('2d'),
    objects: [], // *
    obstacles: [], // maybe change this with a Map()
    config: {
        keys: [],
        playerWidth: 20,
        playerHeight: 20,
        fallSpeed: 1.5,
        canMove: false,
        obstacleWidth: 20,
        gameStarted: false,
        gameFinished: false,
        currentPos: 0
    },

    listeners: () => {
        window.addEventListener("resize", function () {
            // implemented in other version
        });
        window.addEventListener('keyup', function (e) {
            WINDOW.config.keys[e.keyCode] = false;
        });
        window.addEventListener('keydown', function (e) {
            WINDOW.config.keys[e.keyCode] = true;
        });
    },

    clearWindow: ()=> {
        WINDOW.context.clearRect(0, 0, WINDOW.canvas.width, WINDOW.canvas.height);
    },

    createIMG: (src) => {
        let img = new Image();
        img.src = src;
        return img;
    }
};

const player = new Player(
    0,
    (WINDOW.canvas.height / 2) - (WINDOW.config.playerHeight / 2),
    WINDOW.config.playerWidth,
    WINDOW.config.playerHeight,
    WINDOW.context,
    WINDOW.createIMG("img/test.png"),
    WINDOW.canvas
);

const GAME_CONTROLLER = {

    Init: () => {
        player.show();

        GAME_CONTROLLER.Interval.initialize();
    },

    Interval: {
        initialize: () => { setInterval(GAME_CONTROLLER.UpdateArea, 20); },
        clear: () => { clearInterval(GAME_CONTROLLER.interval); }
    },

    UpdateArea: () => {
        WINDOW.clearWindow();
        player.show();
        GAME_CONTROLLER.MovePlayer();
        GAME_CONTROLLER.GenerateObstacles();
        GAME_CONTROLLER.MoveObstacles();
    },

    MovePlayer: () => {
        WINDOW.config.currentPos = player.x;

        if (player.x === (WINDOW.canvas.width / 2) - player.width && !WINDOW.config.gameStarted) {
            player.speedY = WINDOW.config.fallSpeed;
            WINDOW.config.gameStarted = true;
            WINDOW.config.canMove = true;
        }

        player.move();

        // space
        if (WINDOW.config.keys[32] && WINDOW.config.canMove) {
            player.speedY = -player.speedY;
            WINDOW.config.keys[32] = false;
        }
    },

    MoveObstacles: () => {
        WINDOW.obstacles.forEach(e => {
            e.show();
            e.move();

            // todo.. delete objects when disapearing from screen

            // as mentioned in WINDOW.config.. maybe changing this to Map()
        });
    },

    GenerateObstacles: () => {
        if (WINDOW.config.gameStarted && !WINDOW.config.gameFinished) {

            let frq = 0.02; // frequency
            let rdm = Math.floor(Math.random() * 100);
            let pos = Math.floor(Math.random() * 2);

            if ((rdm / 100) < frq) {

                let ObstacleHeight = Math.floor(Math.random() * (WINDOW.canvas.height - player.height * 1.75));

                // the obstacle starts positioned on top
                if (pos === 0) {
                    GAME_CONTROLLER.CreateObstacle(
                        ObstacleHeight,
                        0
                    );
                }

                // the obstacle starts positioned down side
                else {
                    GAME_CONTROLLER.CreateObstacle(
                        ObstacleHeight,
                        WINDOW.canvas.height - ObstacleHeight
                    );
                }
            }
        }
    },

    CreateObstacle: (OBS_HEIGHT, START_POS) => {
        WINDOW.obstacles.push(new Obstacle(
            WINDOW.canvas.width - WINDOW.config.obstacleWidth,
            START_POS,
            WINDOW.config.obstacleWidth,
            OBS_HEIGHT,
            WINDOW.context,
            WINDOW.createIMG("img/test2.png"),
            WINDOW.canvas
        ));
    }
};



// WINDOW ONLOAD
window.onload = () => {

    WINDOW.listeners();
    GAME_CONTROLLER.Init();
};

